$('#myModal').on('show.bs.modal', function (e) {
    var button = $(e.relatedTarget); // выясняем какая картинка запустила модальное окно
    var img = button.data('img'); //получаем данные от атрибута data-img
    var name = button.data('name'); //получаем данные от атрибута dataname
    $(".modaltitle").html(Картинка-города); //вставляем название картинки в заголовок модального окна
    $(".modal-body").html("<img class='img-big'src='"+img+"'>");
    //вставляем картинку в тело модального окна
    })